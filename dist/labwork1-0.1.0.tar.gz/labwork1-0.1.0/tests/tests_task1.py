import pytest
import task1

@pytest.fixture
